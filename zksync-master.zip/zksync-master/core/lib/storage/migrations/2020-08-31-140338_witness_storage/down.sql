DROP TABLE IF EXISTS block_witness;
