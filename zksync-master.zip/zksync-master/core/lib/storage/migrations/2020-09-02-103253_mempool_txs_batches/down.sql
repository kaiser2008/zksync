ALTER TABLE mempool_txs DROP COLUMN batch_id;
ALTER TABLE executed_transactions DROP COLUMN batch_id;
