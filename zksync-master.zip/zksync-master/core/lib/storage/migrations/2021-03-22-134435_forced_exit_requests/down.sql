DROP TABLE IF EXISTS forced_exit_requests;
