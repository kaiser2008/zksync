DROP TABLE IF EXISTS txs_batches_signatures;
