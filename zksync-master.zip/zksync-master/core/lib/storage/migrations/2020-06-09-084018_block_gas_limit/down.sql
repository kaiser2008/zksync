ALTER TABLE blocks DROP COLUMN verify_gas_limit;
ALTER TABLE blocks DROP COLUMN commit_gas_limit;