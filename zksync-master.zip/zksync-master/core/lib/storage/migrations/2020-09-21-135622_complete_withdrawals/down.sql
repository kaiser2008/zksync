DROP TABLE IF EXISTS pending_withdrawals;
DROP TABLE IF EXISTS complete_withdrawals_transactions;
