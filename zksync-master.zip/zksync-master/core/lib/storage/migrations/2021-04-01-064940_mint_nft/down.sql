DROP table mint_nft_updates;
DROP table nft;
ALTER TABLE tokens DROP COLUMN is_nft;
