DROP TABLE nft_factory;
