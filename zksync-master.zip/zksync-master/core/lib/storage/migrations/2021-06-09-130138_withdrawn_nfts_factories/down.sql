DROP TABLE IF EXISTS withdrawn_nfts_factories;
